/* */ 
"use strict";

exports["default"] = typeof global === "undefined" ? self : global;
exports.__esModule = true;