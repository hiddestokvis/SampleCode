/* */ 
module.exports = require('./es7/index');
