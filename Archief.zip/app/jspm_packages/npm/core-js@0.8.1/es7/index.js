/* */ 
require("../modules/es7.array.includes");
require("../modules/es7.string.at");
require("../modules/es7.regexp.escape");
require("../modules/es7.object.get-own-property-descriptors");
require("../modules/es7.object.to-array");
module.exports = require("../modules/$").core;
