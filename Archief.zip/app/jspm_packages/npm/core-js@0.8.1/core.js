/* */ 
module.exports = require('./core/index');
