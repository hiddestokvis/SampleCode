/* */ 
require("../modules/es6.function.name");
module.exports = require("../modules/$").core.Function;
