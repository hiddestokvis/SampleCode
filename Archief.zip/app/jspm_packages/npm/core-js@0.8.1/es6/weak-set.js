/* */ 
require("../modules/es6.string.iterator");
require("../modules/web.dom.iterable");
require("../modules/es6.weak-set");
module.exports = require("../modules/$").core.WeakSet;
