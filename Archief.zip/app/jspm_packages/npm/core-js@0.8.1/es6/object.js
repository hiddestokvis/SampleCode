/* */ 
require("../modules/es6.object.assign");
require("../modules/es6.object.is");
require("../modules/es6.object.set-prototype-of");
require("../modules/es6.object.to-string");
require("../modules/es6.object.statics-accept-primitives");
require("../modules/es6.symbol");
module.exports = require("../modules/$").core.Object;
