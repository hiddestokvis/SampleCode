/* */ 
require("../modules/es6.string.iterator");
require("../modules/web.dom.iterable");
require("../modules/es6.weak-map");
module.exports = require("../modules/$").core.WeakMap;
