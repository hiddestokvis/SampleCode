/* */ 
require("../../modules/core.string.escape-html");
module.exports = require("../../modules/$").core.String.unescapeHTML;
