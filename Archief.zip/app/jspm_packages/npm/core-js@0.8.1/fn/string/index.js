/* */ 
require("../../modules/es6.string.from-code-point");
require("../../modules/es6.string.raw");
require("../../modules/es6.string.iterator");
require("../../modules/es6.string.code-point-at");
require("../../modules/es6.string.ends-with");
require("../../modules/es6.string.includes");
require("../../modules/es6.string.repeat");
require("../../modules/es6.string.starts-with");
require("../../modules/es7.string.at");
require("../../modules/core.string.escape-html");
module.exports = require("../../modules/$").core.String;
