/* */ 
require("../../modules/es7.object.to-array");
module.exports = require("../../modules/$").core.Object.entries;
