/* */ 
require("../../modules/es6.number.statics");
module.exports = require("../../modules/$").core.Number.isNaN;
