/* */ 
require("../../modules/es6.number.constructor");
require("../../modules/es6.number.statics");
require("../../modules/core.number.iterator");
require("../../modules/core.number.math");
module.exports = require("../../modules/$").core.Number;
