/* */ 
require("../../modules/es6.function.name");
require("../../modules/core.binding");
module.exports = require("../../modules/$").core.Function;
