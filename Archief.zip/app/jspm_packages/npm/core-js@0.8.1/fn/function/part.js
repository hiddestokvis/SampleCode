/* */ 
require("../../modules/core.binding");
module.exports = require("../../modules/$").core.Function.part;
