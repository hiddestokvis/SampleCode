/* */ 
module.exports = require("../../modules/$.wks")('split');
