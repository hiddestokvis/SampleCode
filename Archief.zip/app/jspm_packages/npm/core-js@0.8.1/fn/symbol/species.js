/* */ 
module.exports = require("../../modules/$.wks")('species');
