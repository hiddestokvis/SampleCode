/* */ 
module.exports = require("../../modules/$.wks")('search');
