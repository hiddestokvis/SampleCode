/* */ 
module.exports = require("../../modules/$.wks")('toPrimitive');
