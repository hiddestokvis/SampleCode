/* */ 
require("../../modules/es6.reflect");
module.exports = require("../../modules/$").core.Reflect.defineProperty;
