/* */ 
require("../modules/core.object");
require("../modules/core.binding");
module.exports = require("../modules/$").core.Object;
