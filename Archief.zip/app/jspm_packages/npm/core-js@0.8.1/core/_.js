/* */ 
require("../modules/core.binding");
module.exports = require("../modules/$").core._;
