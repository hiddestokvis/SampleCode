/* */ 
require("../modules/core.global");
module.exports = require("../modules/$").core.global;
