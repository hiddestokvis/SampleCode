io.js/node.js core buffer tests
