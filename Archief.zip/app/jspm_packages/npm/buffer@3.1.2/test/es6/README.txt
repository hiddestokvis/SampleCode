io.js/node.js core buffer tests that require ES6 (for..of construct)
