/* */ 
"format global";
module.exports = require("./lib/babel/api/register/node");
