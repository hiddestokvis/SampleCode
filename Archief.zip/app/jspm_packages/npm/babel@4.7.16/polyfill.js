/* */ 
"format global";
module.exports = require("./lib/babel/polyfill");
