/* */ 
module.exports = System._nodeRequire ? System._nodeRequire('events') : require('events-browserify');